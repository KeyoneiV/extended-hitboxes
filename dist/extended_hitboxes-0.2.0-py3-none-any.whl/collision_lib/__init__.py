from .hitboxes import BaseHitbox, CircleHitbox, TriangleHitbox, RotatedRectHitbox
from .dispatch import check_collision